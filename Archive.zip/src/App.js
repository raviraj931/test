// import logo from './logo.svg';
import './App.css';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import styled from 'styled-components';
import { Button, Carousel, Modal } from 'react-bootstrap';
import { useEffect, useState } from 'react';
import Form from 'react-bootstrap/Form';

function App() {

  const [modelShow, setModelShow] = useState(false);
  const [afterLogin, setAfterLogin] = useState("");
  const [afterLoginState, setAfterLoginState] = useState(false);
  const [ImageList, setImageList] = useState([]);

  const [Login, setLogin] = useState({
    username:"test",
    password:"12345678"
  })

  const [LoginError, setLoginError] = useState({
    usernameError:"",
    passwordError:""
  })

  const handleShow = () => {
    setModelShow(true)
  }
  const handleClose = () => {
    setModelShow(false)
  }

useEffect(()=>{

  if(afterLogin == ""){
    setImageList([ {
      image_url:'https://mdbootstrap.com/img/Photos/Slides/img%20(15).webp',
      title:'First slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    },
    {
      image_url:'https://mdbootstrap.com/img/Photos/Slides/img%20(22).webp',
      title:'Second slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    },
    {
      image_url:'https://mdbootstrap.com/img/Photos/Slides/img%20(23).webp',
      title:'Thired slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    },
    {
      image_url:'https://mdbootstrap.com/img/new/slides/041.webp',
      title:'Fourth slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    }])
  }else{
    setImageList([ {
      image_url:'https://mdbootstrap.com/img/new/slides/042.webp',
      title:'First slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    },
    {
      image_url:'https://mdbootstrap.com/img/new/slides/043.webp',
      title:'Second slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    },
    {
      image_url:'https://mdbootstrap.com/img/Photos/Slides/img%20(19).webp',
      title:'Thired slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    },
    {
      image_url:'https://mdbootstrap.com/img/Photos/Slides/img%20(35).webp',
      title:'Fourth slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    },{
      image_url:'https://mdbootstrap.com/img/Photos/Slides/img%20(40).webp',
      title:'Fourth slide label',
      describe:'Nulla vitae elit libero, a pharetra augue mollis interdum.'
    }])
  }

},[afterLogin])

const login=()=>{
  let flag=true
  let usernameError,passwordError;

  if(Login.username == ''){
    flag=false;
    usernameError='Please Enter User Name';
  }
  if(Login.username != 'test'){
    flag=false;
    usernameError='Wrong User Name';
  }

  if(Login.password == ''){
    flag=false;
    passwordError='Please Enter Password';
  }
  if(Login.password != '12345678'){
    flag=false;
    passwordError='Wrong Password';
  }
  if(flag == false){
    setLoginError({...LoginError,usernameError:usernameError,passwordError:passwordError})
  }else{
    setCookie("username",Login.username,360)
    setCookie("password",Login.password,360)
    setLogin({...Login,username:'',password:''})
    handleClose()
  }

}

useEffect(() => {
 if(modelShow == false){
  const username=getCookie("username");
  if(username){
    setAfterLogin(username);
    setAfterLoginState(true)
  }else{
    setAfterLoginState(false)
  }

 }

}, [modelShow])



function setCookie(cname, cvalue, minutes) {
  var d = new Date();
  d.setTime(d.getTime() + (minutes*60*1000));
  var expires = "expires="+ d.toUTCString();
  document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}

const LogOut=()=>{
  delete_cookie('username');
  delete_cookie('password');
 
    setAfterLogin("");
    setAfterLoginState(false)
  

 
}
var delete_cookie = function(name) {
  document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
};

  return (
    <div>
      <MainHeader>
        <Navbar bg="light" expand="lg">
          <Container>
            <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="" style={{ marginLeft: 'auto' }}>
                <Nav.Link href="#home">Home</Nav.Link>
                <Nav.Link href="#link">Link</Nav.Link>
                {afterLoginState ?
                <LoginBtn onClick={LogOut}> {afterLogin} </LoginBtn>
                :
                <LoginBtn onClick={handleShow}> login </LoginBtn>}
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </MainHeader>


      <MainSlider>
        <Container>
          <Carousel>
            {ImageList && ImageList.map((item,i)=>(
              
                <Carousel.Item interval={500} key={i}>
              <img
                className="d-block w-100 fit-full"
                src={item.image_url}
                alt="First slide"
              />
              <Carousel.Caption>
                <h3>{item.title}</h3>
                <p>{item.describe}</p>
              </Carousel.Caption>
            </Carousel.Item>
              
            ))}
            {/* <Carousel.Item interval={1000}>
              <img
                className="d-block w-100"
                src="./img/1.jpg"
                alt="First slide"
              />
              <Carousel.Caption>
                <h3>First slide label</h3>
                <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
              </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item interval={500}>
              <img
                className="d-block w-100"
                src="./img/2.jpg"
                alt="Second slide"
              />
              <Carousel.Caption>
                <h3>Second slide label</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="./img/3.jpg"
                alt="Third slide"
              />
              <Carousel.Caption>
                <h3>Third slide label</h3>
                <p>
                  Praesent commodo cursus magna, vel scelerisque nisl consectetur.
                </p>
              </Carousel.Caption>
            </Carousel.Item> */}
          </Carousel>
        </Container>
      </MainSlider>


      {/* Loging Modal */}

      <Modal
        show={modelShow}
        onHide={handleClose}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control type="email" placeholder="Enter email" value={Login.username} onChange={(e=>{setLogin({...Login,username:e.target.value})})} />
              {LoginError.usernameError &&
               <Form.Text className=" text-danger">
               {LoginError.usernameError}
             </Form.Text>
              }
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="Password" value={Login.password} onChange={(e=>{setLogin({...Login,password:e.target.value})})}  />
              {LoginError.passwordError &&
               <Form.Text className="text-danger">
               {LoginError.passwordError}
             </Form.Text>
              }
             
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" type="button" onClick={()=>{login()}}>
            Submit
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default App;

const LoginBtn = styled.button`
  min-width: 120px;
  width:100%;
  height: 40px;
  background-color: #000066;
  border:none;
  color: #fff;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  margin-left: 10px;
`;


const MainHeader = styled.div`
  position:fixed;
  width: 100%;
  z-index: 1111;
`;

const MainSlider = styled.div`
  max-height: 700px;
  height: 100%;

  .carousel-caption{
    bottom: 25.25rem;
  }

`;